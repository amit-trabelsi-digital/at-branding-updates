<?php
	wp_enqueue_media();
?>

<div class="wrap">
	<h2><?php _e( 'Custom Branding', 'at' ); ?>
		<small><?php _e( 'by', 'at' ); ?> <a href="<?php echo $this->atURL; ?>"><?php _e( 'AT Digital', 'at' ); ?></a></small>
	</h2>
	<form action="options.php" method="post">
		<?php settings_fields( 'at-branding' ); ?>
		<?php do_settings_fields( 'at-branding' ,''); ?>

		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="clients_main_color"><?php _e( 'Client\'s Main Color', 'at' ); ?></label></th>
					<td>
						<input style='width: 80px;height:50px' type="color" name="clients_main_color" id="clients_main_color" class="regular-text" value="<?php echo get_option( 'clients_main_color' ); ?>">
						<p class="description" id="clients_main_color-description"><?php _e( 'Enter the client\'s main color in hex format including hash symbol.', 'at' ); ?></p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="clients_logo_file"><?php _e( 'Client\'s Logo', 'at' ); ?></label></th>
					<td>
						<input type="hidden" id="clients_logo_file" name="clients_logo_file" class="regular-text" value="<?php echo esc_url( get_option( 'clients_logo_file' ) ); ?>" />
						<input id="clients_logo_file_button" type="button" class="button" value="<?php _e( 'Upload', 'at' ); ?>" />
						<p class="description" id="clients_main_color-description"><?php _e( 'Upload the client\'s logo to disaply it on the login page.', 'at' ); ?></p>
						<div id="clients_logo_file_preview">
							<?php if( get_option( 'clients_logo_file' ) != '' ) : ?>
							<img src="<?php echo get_option( 'clients_logo_file' ); ?>">
							<span class='remove_img' data-type='clients_logo_file'>&#x2716;</span>
							<?php endif; ?>
						</div>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="admin_favicon_file"><?php _e( 'Admin\'s favicon', 'at' ); ?></label></th>
					<td>
						<input type="hidden" id="admin_favicon_file" name="admin_favicon_file" class="regular-text" value="<?php echo esc_url( get_option( 'admin_favicon_file' ) ); ?>" />
						<input id="admin_favicon_file_button" type="button" class="button" value="<?php _e( 'Upload', 'at' ); ?>" />
						<p class="description" id="admin_favicon_file-description"><?php _e( 'Upload the admin\'s favicon to disaply it on the login page & admin interface.', 'at' ); ?></p>
						<div id="admin_favicon_file_preview">
							<?php if( get_option( 'admin_favicon_file' ) != '' ) : ?>
							<img src="<?php echo get_option( 'admin_favicon_file' ); ?>">
							<span class='remove_img' data-type='admin_favicon_file'>&#x2716;</span>
							<?php endif; ?>
						</div>
					</td>
				</tr>


				<tr valign="top"><th scope="row"><h2>Email Settings</h2></th></tr>

				<tr valign="top">
					<th scope="row"><label for="at_use_sendgrid"><?php _e( 'Use SendGrid', 'at' ); ?></label></th>
					<td>
						<input type="checkbox" id="at_use_sendgrid" name="at_use_sendgrid" class="regular-text" <?= get_option( 'at_use_sendgrid' ) ? 'checked': '' ?> />
						<span class="description" id="at_use_sendgrid-description"><?php _e( 'Check this to send all emails via SendGrid', 'at' ); ?></span>
					</td>
				</tr>

				<tr valign="top">
					<th scope="row"><label for="at_sender_email_name"><?php _e( 'Email Name', 'at' ); ?></label></th>
					<td>
						<input type="text" id="at_sender_email_name" name="at_sender_email_name" class="regular-text" value="<?php echo esc_html( get_option( 'at_sender_email_name' ) ); ?>" />
						<p class="description" id="at_sender_email_name-description"><?php _e( 'Update Email From Name , default: blog name', 'at' ); ?></p>
					</td>
				</tr>

				<tr valign="top">
					<th scope="row"><label for="at_sender_email_address"><?php _e( 'Email Address', 'at' ); ?></label></th>
					<td>
						<input type="Email" id="at_sender_email_address" name="at_sender_email_address" class="regular-text" value="<?php echo esc_html( get_option( 'at_sender_email_address' ) ); ?>" />
						<p class="description" id="at_sender_email_address-description"><?php _e( 'Update Email From Address , default: info@site-url.com', 'at' ); ?></p>
					</td>
				</tr>

				<?php
					if ( class_exists( 'GFCommon' ) ) {
				?>
				<tr valign="top">
					<th scope="row"><label for="at_sent_to_admin_default"><?php _e( 'Admin Email', 'at' ); ?></label></th>
					<td>
						<input type="Email" id="at_sent_to_admin_default" name="at_sent_to_admin_default" class="regular-text" value="<?php echo esc_html( get_option( 'at_sent_to_admin_default' ) ); ?>" />
						<p class="description" id="at_sent_to_admin_default-description"><?php _e( 'Gravity Forms - update default sent to admin email , default: admin email', 'at' ); ?></p>
					</td>
				</tr>

				<?php
					}				
				?>

			</tbody>
		</table>

		<?php submit_button(); ?>
	</form>
</div>