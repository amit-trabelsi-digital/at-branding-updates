<?php
list($r, $g, $b) = array_map(
	function ($c) {
	  return hexdec(str_pad($c, 2, $c));
	},
	str_split(ltrim($clientColor, '#'), strlen($clientColor) > 4 ? 2 : 1)
  );

?>

<style>
	body {
		background: rgba(<?=$r?>,<?=$g?>,<?=$b?>, 0.3) url(   <?= home_url() ?>/wp-content/plugins/at-branding/assets/images/login-background.jpg) no-repeat center center;
		background-blend-mode: multiply;	
	}

	.login h1 a {
		width: 320px;
		height: 100px;
		background: transparent url( '<?php echo $clientLogo; ?>' ) no-repeat center center;
		background-size: contain;
	}

	.login form {
		background-color: rgba( 255, 255, 255, .5 );
	}

	.login label {
		font-weight: normal;
		color: #313131;
	}

	.login form .input,
	.login form input[type=checkbox],
	.login input[type=text] {
		background-color: #fefefe;
		border-color: <?php echo $clientColor; ?>;
	}

	.login input[type=text],
	.login input[type=password] {
		padding: 10px;
		font-size: 14pt;
	}

	.wp-core-ui .button-group.button-large .button,
	.wp-core-ui .button.button-large {
		-webkit-box-shadow: none;
		box-shadow: none;
		border-color: <?php echo $clientColor; ?>;
		background-color: <?php echo $clientColor; ?>;
	}

	#websuit-footer {
		position: absolute;
		bottom: 0;
		width: 100%;
		padding: 15px 0;
		text-align: center;
		background-color: #fff;
	}

	.wp-core-ui .button-primary {
		background: <?php echo $clientColor; ?>;
		color: #fff;
		text-decoration: none;
		text-shadow: 0 -1px 1px <?php echo $clientColor; ?>, 1px 0 1px <?php echo $clientColor; ?>, 0 1px 1px <?php echo $clientColor; ?>, -1px 0 1px <?php echo $clientColor; ?>;
	}

	#websuit-footer img {
		width: 120px;
	}
</style>