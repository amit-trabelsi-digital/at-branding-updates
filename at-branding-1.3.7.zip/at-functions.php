<?php
// Exit if accessed directly
defined('ABSPATH') || exit;

	/**
	 * Created by PhpStorm.
	 * User: athbss
	 * Date: 23/01/2018
	 * Time: 22:04
	 */

	add_action('admin_bar_menu', 'show_me_the_template', 124);
	//add_action( 'admin_enqueue_scripts', 'at_admin_scripts' );
	add_action('admin_head', 'at_admin_css');

	define( 'THEME', get_template_directory_uri() );
	// define('WP_DEV', ($_SERVER['REMOTE_ADDR'] == '::1' || $_SERVER['REMOTE_ADDR'] == '127.0.0.1') ? true : false);
	define('WP_DEV', get_option('wp_at_env') === 'PROD' ? false : true);

  //
  // Show File name in admin bar
  //
	function show_me_the_template(){
		if ( ! is_admin() ) if (current_user_can( 'manage_options' )) if ( is_admin_bar_showing() ) {
			global $template, $wp_admin_bar;
			//get_currentuserinfo();
			$str_trim = dirname(__FILE__) . '/';
			$template_text = trim($template, $str_trim);
			$template_text = str_replace($str_trim," File Name: ",$template);
			$path = explode('/', $template_text);

			if ( is_admin_bar_showing() ) {
				$wp_admin_bar->add_menu( array(
					'parent' => false,
					'id' => 'template',
					'title' => end($path),
					'href' => '#',
					'meta' => array('title' => $template_text)
				));
			}
		}

		?>
      <style>
        @namespace url(http://www.w3.org/1999/xhtml);

        .xdebug-var-dump {
          background: #fef9fb !important;
          color: #000 !important;
          padding: 4px 8px !important;
          margin: 5px 10px !important;
          text-align: left !important;
          font-family: Menlo, Monaco, "Consolas", "Lucida Console", "courier new" !important;
          -moz-border-radius: 10px !important;
          -webkit-border-radius: 10px !important;
          -o-border-radius: 10px !important;
          border-radius: 10px !important;
          border: solid 3px #942343 !important;
          font-size: 10px;
          z-index: 999999 !important;
          display: block;
          position: inherit;
        }

        .xdebug-error {
          color: #333 !important;
          margin: 5px 10px !important;
          font-family: Tahoma !important;
          -moz-border-radius: 10px !important;
          -webkit-border-radius: 10px !important;
          -o-border-radius: 10px !important;
          border-radius: 10px !important;
          border: solid 3px #942343 !important;
        }

        .xdebug-error td ,
        .xdebug-error th {
          padding: 4px !important;
          border-collapse: collapse !important;
          vertical-align: top;
        }

        .xdebug-error > tbody > tr:first-child > th {
          background: #942343 !important;
          color: #fff !important;
          font-size: 22px !important;
          font-weight: normal;
          font-family: Verdana !important;
        }

        .xdebug-error > tbody > tr:first-child > th span {
          background: #f39800 !important;
          margin: 2px;
          padding: 5px;
          line-height: 150%;
          font-size: 12px !important;
          vertical-align: middle;
          color: #fff !important;
          border: solid 2px #f39800;
          -moz-border-radius: 20px;
          -webkit-border-radius: 20px !important;
          -o-border-radius: 20px !important;
          border-radius: 20px !important;
          height: 20px !important;
          display: block !important;
          float: left !important;
        }

        .xdebug-error th {
          background: -moz-linear-gradient(top, #fff, #ececec) !important;
          background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#ececec)) !important;
        }

        .xdebug-error th {
          border-right: solid 1px #ececec !important;
        }

        .xdebug-error th:last-child {
          border-right: 0 !important;
        }

        .xdebug-error td {
          background: #fef9fb !important;
          font-family: Menlo, Monaco, "Consolas", "Lucida Console", "courier new" !important;
        }

        .xdebug-error td {
        }

        .xdebug-error td {
          border-right: dashed 1px #f0f0f0 !important;
          border-bottom: dashed 1px #f0f0f0 !important;
        }

        .xdebug-error td:last-child {
          border-right: 0 !important;
        }

        .xdebug-error tr:last-child td {
          border-bottom: 0 !important;
        }

        .xdebug-error tr:last-child th ,
        .xdebug-error tr:last-child td {
          -moz-border-radius: 10px !important;
          -webkit-border-radius: 10px !important;
          -o-border-radius: 10px !important;
          border-radius: 10px !important;
        }

        font[color="#00bb00"] ,
        font[color="#4e9a06"] {
          color: #618e34 !important;
        }

        font[color="#ff0000"] ,
        font[color="#cc0000"] {
          color: #d83473 !important;
        }

        font[color="#3465a4"] {
          color: #0075c2 !important;
        }

        .xdebug-error .xdebug-var-dump {
          padding: 0 !important;
          margin: 0 !important;
          -moz-border-radius: 10px !important;
          -webkit-border-radius: 10px !important;
          -o-border-radius: 10px !important;
          border-radius: 10px !important;
          border: none !important;
        }

        body > .xdebug-var-dump {
          margin-top: 50px !important;
        }
      </style>
      <?php
	}

	function at_admin_css() {
		?>
    <style>

    </style>
		<?php
	}

	add_action( 'init', 'disable_wp_emojicons' );
	function disable_wp_emojicons() {

		// all actions related to emojis
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	}

  if( get_option( 'at_use_sendgrid' ) ){
    add_action( 'phpmailer_init', 'at_send_mail_using_smtp' );
  }

	function at_send_mail_using_smtp( $phpmailer ) {
		$phpmailer->isSMTP();
		$phpmailer->SMTPAuth = true;
		$phpmailer->IsHTML(true);

		if(WP_DEV){
      $phpmailer->Port = 2525;

      $phpmailer->Host = 'smtp.mailtrap.io';

			// Amit Mailtrap
			$phpmailer->Username = 'd3338ad3f09d56';
			$phpmailer->Password = '6850d48f7af7b6';
		}
		else{
      $phpmailer->Host = 'smtp.sendgrid.net';
      $phpmailer->Port = 25;
      $phpmailer->Username = 'apikey';
      $phpmailer->Password = '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';

      $phpmailer->SMTPSecure = 'tls';
		}
		$phpmailer->FromName = atb_mail_from_name();
		$phpmailer->From = atb_mail_from();


	}
add_action('wp_mail_failed', 'log_mailer_errors', 10, 1);
function log_mailer_errors( $wp_error ){
  $fn = ABSPATH . '/mail.log'; // say you've got a mail.log file in your server root
  $fp = fopen($fn, 'a');
  fputs($fp, "Mailer Error: " . $wp_error->get_error_message() ."\n");
  fclose($fp);
}

add_filter ("wp_mail_content_type", "my_awesome_mail_content_type");
function my_awesome_mail_content_type() {
    return "text/html";
}

if( !get_option( 'at_use_sendgrid' ) ){
  add_filter ("wp_mail_from", "atb_mail_from");
  add_filter ("wp_mail_from_name", "atb_mail_from_name");
}

function atb_mail_from() {
  $at_sender_email_address = get_option('at_sender_email_address');
  $protocols = array('http://','https://', 'http://www.', 'https://www.', 'www.');
  $site =  str_replace($protocols, '', get_bloginfo('wpurl'));
  return $at_sender_email_address ? $at_sender_email_address : 'info@' . $site ;
}

function atb_mail_from_name() {
  $at_sender_email_name = get_option('at_sender_email_name');
  return $at_sender_email_name ? $at_sender_email_name : get_bloginfo( 'name' );
}

if ( class_exists( 'GFCommon' ) ) {
  add_filter( 'gform_pre_send_email', 'atd_gform_before_email' );
}

function atd_gform_before_email( $email ) {
  	
    $admin_email = get_option('at_sent_to_admin_default');

  	if( $admin_email ){
      	$email['to'] = $admin_email;	
    }
  
  	return $email;
}




add_filter('wp_mail', 'my_wp_mail');
 
function my_wp_mail($atts) {
  $base = $atts['message'];
  ob_start();
  ?>
  <html dir="rtl">
    <head>

        <title><?php echo get_bloginfo( 'name' ); ?></title>
<style>
/*
  br{
    display: none !important;
  }
*/
  
  ._row br{
    display: block;
  }
  .gf-all-fields{
    list-style: none;
  }
</style>
    </head>
    <body style="text-align: right; font-family: arial; padding: 30px;">
        <div id="email_container" style="background:#fff; direction: rtl;">

            <div style="width:750px; padding:0 20px 20px 20px; background:#fff; margin:30px auto; border:1px #ccc solid;
                moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; color:#454545;line-height:1.5em; " id="email_content">

               <div style="width:160px; margin: 10px auto;text-align:center;">
                <?php if( get_option( 'clients_logo_file' ) != '' ) : ?>
							<img style="width:160px; text-align:center;" width="160" height="auto" src="<?php echo get_option( 'clients_logo_file' ); ?>">
							<?php endif; ?>
               </div>
               
                <h1 style="padding:10px 0 3px 0; font-weight:500;font-size:24px;color:#000;border-bottom:1px solid #bbb">
                   <?php echo $atts['subject']; ?>
                </h1>

                <p style="direction: rtl; unicode-bidi: plaintext;">
                  <?php echo $base; ?>
                </p>


                <div style="text-align:center; border-top:1px solid #eee;padding:5px 0 0 0;" id="email_footer"> 
                    <small style="font-size:11px; color:#999; line-height:14px;">
קיבלת הודעה זו מ<?php echo get_bloginfo( 'name' ); ?> - <?php  echo get_bloginfo( 'url' ); ?>
                    </small>
                </div>

            </div>
        </div>
        <div style="text-align:center;padding:5px 0 0 0;" id="email_footer"> 
                    <small style="direction: ltr;font-size:9px; color:#999; line-height:12px;">
                      הקמה וניהול: 
<a href="https://amit-trabelsi.co.il">עמית טרבלסי</a>
                                         </small>
                </div>
    </body>
</html>
  
  <?php 
   $message = ob_get_contents();
    ob_end_clean();
//$atts['message'] .= ' - Site Name';
  
  
  $atts['message'] = $message;
return $atts;
}

//add_filter( 'gform_pre_send_email', function ( $email, $message_format ) {
//  
//  var_dump($email);
//  var_dump(htmlentities2($email['message']));
//  
////    if ( $message_format != 'html' ) {
////        return $email;
////    }
//// 
////    $email['message'] = '<html>' . $email['message'] . '</html>';
//// 
//    return $email;
//}, 10, 2 );

	//if(class_exists('acf')){
	function my_acf_init() {

		  acf_update_setting('google_api_key', 'AIzaSyDwqHJtbTUPGenA03olTgz13HVRDIrDncU');
	  //}

	  add_action('acf/init', 'my_acf_init');
  }

  // LTR Admin
  function admin_body_ltr_scripts()
  {
    wp_enqueue_style( 'admin-body-ltr', plugins_url( 'assets/css/ltr-admin.css' , __FILE__ ) );
    wp_enqueue_script( 'admin-body-ltr', plugins_url( 'assets/js/ltr-admin.js' , __FILE__ ), array( 'jquery' ), '0.1', true );

    wp_localize_script( 'admin-body-ltr', 'script_vars',
        array( 'AJAXurl' => admin_url( 'admin-ajax.php' ) ) );
  }
  add_action( 'admin_enqueue_scripts', 'admin_body_ltr_scripts' );

  function admin_body_ltr_adminbar($wp_admin_bar)
  {
    $env = (WP_DEV) ? 'DEV' : 'PROD';
    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $args = array(
        'id' => 'at_env'.'_'.strtolower($env),
        'title' => '<span id="at_env">'. $env .'</span>',
        'href' => "?wp_at_env=$env&re=" . urlencode($actual_link),
        'meta' => array(
            'class' => 'admin-env-btn-adminbar',
            'title' => __('Switch environment', 'ltr-admin')));

    $wp_admin_bar->add_node($args);
    
    if (!is_admin())
      return;

    $args = array(
        'id' => 'custom-button',
        'title' => '<span id="dir-rtl">RTL</span><i></i><span id="dir-ltr">LTR</span>',
        'href' => '#',
        'meta' => array(
            'class' => 'admin-body-ltr-adminbar',
            'title' => __('Switch admin content direction between RTL and LTR', 'ltr-admin')));

    $wp_admin_bar->add_node($args);

  }
  add_action('admin_bar_menu', 'admin_body_ltr_adminbar', 100);



  //change environment function 
  function wp_at_env_store(){
    if( isset($_GET['wp_at_env'])){
      $env = $_GET['wp_at_env'] == 'PROD' ? 'DEV' : 'PROD';
      update_option( 'wp_at_env', $env );
      wp_redirect($_GET['re']);
      exit;
    }
  }
  add_action('init', 'wp_at_env_store');

/**
 * Add svg MIME type support
 *
 * @param $mimes
 *
 * @author fadupla
 * @return mixed
 */
function fadupla_mime_types( $mimes ) {
  $mimes['svg'] = 'image/svg+xml';

  return $mimes;
}

add_filter( 'upload_mimes', 'fadupla_mime_types' );

/**
 * Ajax get_attachment_url_media_library
 * @author fadupla
 
function fadupla_get_attachment_url_media_library() {

  $url          = '';
  $attachmentID = isset( $_REQUEST['attachmentID'] ) ? $_REQUEST['attachmentID'] : '';
  if ( $attachmentID ) {
    $url = wp_get_attachment_url( $attachmentID );
  }

  echo $url;

  die();
}

add_action( 'wp_ajax_svg_get_attachment_url', 'fadupla_get_attachment_url_media_library' );
*/

/**
 * קבלת הגרסה הנוכחית של הפלאגין
 */
function at_get_plugin_version() {
    static $version = null;
    
    if ($version === null) {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        $plugin_data = get_plugin_data(dirname(__FILE__) . '/at-branding.php');
        $version = $plugin_data['Version'];
    }
    
    return $version;
}

/**
 * יצירת קובץ JSON עם מידע על הפלאגין
 */
function at_generate_plugin_info() {
    $version = at_get_plugin_version();
    $is_dev = isset($_GET['channel']) && $_GET['channel'] === 'dev';
    
    // אם זו בקשה לגרסת פיתוח, נוסיף את המילה dev למספר הגרסה
    if ($is_dev) {
        $version .= '-dev';
    }
    
    return json_encode([
        'at-branding/at-branding.php' => [
            'version' => $version,
            'package' => sprintf(
                'https://github.com/amit-trabelsi-digital/at-branding-wp-plugin/releases/latest/download/at-branding%s.zip',
                $is_dev ? '-dev' : ''
            ),
            'name' => sprintf(
                'AT - Custom Branding%s',
                $is_dev ? ' (Development)' : ''
            ),
            'slug' => 'at-branding',
            'author' => 'Amit Trabelsi',
            'channel' => $is_dev ? 'dev' : 'stable'
        ]
    ], JSON_PRETTY_PRINT);
}

// הוספת נקודת קצה ל-REST API שתחזיר את המידע העדכני
add_action('rest_api_init', function() {
    register_rest_route('at-branding/v1', '/info', [
        'methods' => 'GET',
        'callback' => 'at_generate_plugin_info',
        'permission_callback' => '__return_true'
    ]);
});