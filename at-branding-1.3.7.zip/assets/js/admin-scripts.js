jQuery( document ).ready( function( $ ) {

	// var _preview_target = '';

	// Change the color preview color while use types.
	// $( '#clients_main_color' ).on( 'keyup', function() {

	// 	$( '#clients_main_color_preview' ).css( 'background-color', $( this ).val() );

	// } );

	$('#clients_logo_file_button').click(function(e) {
		e.preventDefault();
		var image = wp.media({ 
			title: 'Upload Image',
			multiple: false,
			type : 'image',
		}).open()
		.on('select', function(e){
			var uploaded_image = image.state().get('selection').first();
			var image_url = uploaded_image.toJSON().url;
			$( '#clients_logo_file' ).val(image_url);
			$( '#clients_logo_file_preview' ).html(`<img src='${image_url}'><span class='remove_img'>&#x2716;</span>`);

		});
	});

	$(document).on('click', '.remove_img', function(){
		$id = $(this).data('type');
		$( '#'+$id+'_preview' ).html('');
		$( '#'+$id ).val('');
	});


	// Display the media upload screen on click.
	// $( '#clients_logo_file_button' ).on( 'click', function() {

	// 	tb_show( 'Upload a logo', 'media-upload.php?referer=custom_branding&type=image&TB_iframe=true&post_id=0', false  );
	// 	_preview_target = 'clients_logo_file';
	// 	return false;

	// } );

	$('#admin_favicon_file_button').click(function(e) {
		e.preventDefault();
		var image = wp.media({ 
			title: 'Upload Image',
			multiple: false,
			type : 'image',
		}).open()
		.on('select', function(e){
			var uploaded_image = image.state().get('selection').first();
			var image_url = uploaded_image.toJSON().url;
			$( '#admin_favicon_file' ).val(image_url);
			$( '#admin_favicon_file_preview' ).html(`<img src='${image_url}'><span class='remove_img'>&#x2716;</span>`);

		});
	});

	// $( '#admin_favicon_file_button' ).on( 'click', function() {

	// 	tb_show( 'Upload a logo', 'media-upload.php?referer=custom_branding&type=image&TB_iframe=true&post_id=0', false  );
	// 	_preview_target = 'admin_favicon_file';
	// 	return false;

	// } );

	// // Assign the uploaded file url to the input.
	// window.send_to_editor = function( html ) {

	// 	var logoFile = $( 'img', html );

	// 	$( '#'+ _preview_target ).val( logoFile.attr( 'src' ) );
	// 	$( '#'+ _preview_target +'_preview' ).html( logoFile );

	// 	tb_remove();

	// }

} );