var $ = jQuery;

jQuery(document).ready(
    function()
    {
      var body = jQuery('body');
      var address = window.location.href.replace(/#.*/, '').replace(/.settings-updated=.*/, '');
      if (localStorage[address] != undefined && localStorage[address] == 'LTR')
        body.addClass('ltr-admin');

       mediaGridObserver.observe(document.body, {
    childList: true,
    subtree: true
  });

  attachmentPreviewObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
      
      jQuery('#wpadminbar .admin-body-ltr-adminbar a.ab-item').click(
          function()
          {
            if (body.hasClass('ltr-admin'))
            {
              localStorage[address] = 'RTL';
              body.removeClass('ltr-admin');
            }
            else
            {
              localStorage[address] = 'LTR';
              body.addClass('ltr-admin');
            }
            return false;
          }
      );

      if($('.acf-hndle-cog').length){
        console.log('acf exist');


        $( "[data-name]" ).each(function( index, element ) {
          var more_info = 'data-name: ' + $( this ).attr('data-name') + ' | ' + 'data-type: '+ $( this ).attr('data-type');
          var float = 'right';
          if(isRtl){
            float = 'left';
          }

          if($( this ).hasClass('acf-th')){
            $( this ).prepend('<small style="float:'+float+';">'+ more_info+'</small>');
					}
          else{
            $( this ).children('.acf-label').prepend('<small style="float:'+float+';">'+ more_info+'</small>');
					}

        });
      }

      $('[data-name="members"] .acf-actions').append('<button form="export" class="_export_btn acf-button button button-primary">ייצוא נרשמים</button>');

      $('._export_btn').on('click', function () {
        var _pid = $('#post_ID').val();
        var _data = {
          'action': 'at_export_subscribers',
          'pid': _pid
        };
        $.ajax({
          url: script_vars.AJAXurl,
          method: 'POST',
          data: _data
        }).done(function (res) {
          var data = JSON.parse(res);
          console.log(data);
          if (data.success) {
            if (data.path) {
              //Create an hidden iframe, with the 'src' attribute set to the created ZIP file.
              var dlif = $('<iframe/>', {'src': data.path}).hide();
              //Append the iFrame to the context
              $('body').append(dlif);

            }
          }
          else {
            alert('אין הרשאות מתאימות');
          }
        });
      });
    }
);

var mediaGridObserver = new MutationObserver(function (mutations) {

  for (var i = 0; i < mutations.length; i++)
  {

    for (var j = 0; j < mutations[i].addedNodes.length; j++)
    {
      element = $(mutations[i].addedNodes[j]);

      if (element.attr('class'))
      {
        elementClass = element.attr('class');
        if (element.attr('class').indexOf('attachment') != -1)
        {

          attachmentPreview = element.children('.attachment-preview');
          if (attachmentPreview.length != 0)
          {
            if (attachmentPreview.attr('class').indexOf('subtype-svg+xml') != -1)
            {
              var handler = function (element) {

                jQuery.ajax({

                  url: script_vars.AJAXurl,
                  type: "POST",
                  dataType: 'html',
                  data: {
                    'action': 'svg_get_attachment_url',
                    'attachmentID': element.attr('data-id')
                  },
                  success: function (data) {
                    if (data)
                    {
                      element.find('img').attr('src', data);
                      element.find('.filename').text('SVG Image');
                    }
                  }
                });

              }(element);

            }
          }
        }
      }
    }
  }
});

var attachmentPreviewObserver = new MutationObserver(function (mutations) {
  for (var i = 0; i < mutations.length; i++)
  {
    for (var j = 0; j < mutations[i].addedNodes.length; j++)
    {
      var element = $(mutations[i].addedNodes[j]);
      var onAttachmentPage = false;
      if ((element.hasClass('attachment-details')) || element.find('.attachment-details').length != 0)
      {
        onAttachmentPage = true;
      }

      if (onAttachmentPage == true)
      {
        var urlLabel = element.find('label[data-setting="url"]');
        if (urlLabel.length != 0)
        {
          var value = urlLabel.find('input').val();
          element.find('.details-image').attr('src', value);
        }
      }
    }
  }
});